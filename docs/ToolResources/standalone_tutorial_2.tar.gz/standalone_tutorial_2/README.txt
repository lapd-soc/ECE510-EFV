Standalone Tutorial 2 
DUT + Testcases in Memory Approach for Standalone Emulation Mode 
