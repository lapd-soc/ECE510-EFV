Standalone Tutorial 3
Only DUT 
In this implementation, only DUT is synthesized as top level.
Hence "comp -top adder" in veloce.config as adder module is the top level.
There is no testbench, user to manually push vectors on input.
This is achieved through run.do file reg setvalue commands. 
This is useful to quickly check if a design is synthesizable. 
